import './assets/mystyle.css'
import { useState } from 'react'
import  bun  from './assets/react.svg'




function Header() {
    

    const [count,setCount] = useState(0)
    let name = ["Abass1", "Abass2","Abass3","Abass3","Abass4"]
  

    return (

<>
<div className='coverpage' >


<nav className ="nav1">

     <ul className ="ul1">
        <img src={bun}></img>
    </ul>
    <ul className ="ul1">
    <li id="boss">Home</li>
        <li>contact</li>
        <li>Service</li>
        <li>About</li>
       
        <button onClick={ () => setCount((count)=> count + 1 ) }>{count}</button>
    </ul>
    <ul className ="ul1">
    <li id="boss">Home</li>
        <li>contact</li>
        <li>Service</li>
        <li>About</li>
       
        <button onClick={ () => setCount((count)=> count + 1 ) }>{count}</button>
    </ul>
    
</nav>
<div></div>
</div>
</>

    )
//    [count,setCount] = useState(0)
}

export default Header